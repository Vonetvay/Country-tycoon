using UnityEngine;

public class Shop : MonoBehaviour
{
    [SerializeField] private ShopMenu _shopMenu;
}
