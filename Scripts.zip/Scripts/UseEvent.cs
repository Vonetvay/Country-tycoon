using UnityEngine;
using UnityEngine.Events;

public static class UseEvent
{
    public static UnityEvent<int> Use = new UnityEvent<int>();
}
